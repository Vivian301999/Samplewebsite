<?php
	
	$advance_training_academy_custom_css = '';
	/*---------------------------Width Layout -------------------*/
	$advance_training_academy_theme_lay = get_theme_mod( 'advance_training_academy_theme_options','Default');
    if($advance_training_academy_theme_lay == 'Default'){
		$advance_training_academy_custom_css .='body{';
			$advance_training_academy_custom_css .='max-width: 100%;';
		$advance_training_academy_custom_css .='}';
	}else if($advance_training_academy_theme_lay == 'Container'){
		$advance_training_academy_custom_css .='body{';
			$advance_training_academy_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$advance_training_academy_custom_css .='}';
		$advance_training_academy_custom_css .='.serach_outer{';
			$advance_training_academy_custom_css .='width: 97.7%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto';
		$advance_training_academy_custom_css .='}';
	}else if($advance_training_academy_theme_lay == 'Box Container'){
		$advance_training_academy_custom_css .='body{';
			$advance_training_academy_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$advance_training_academy_custom_css .='}';
		$advance_training_academy_custom_css .='.serach_outer{';
			$advance_training_academy_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto; right:0';
		$advance_training_academy_custom_css .='}';
		$advance_training_academy_custom_css .='.page-template-custom-front-page #header{';
			$advance_training_academy_custom_css .='right:0;';
		$advance_training_academy_custom_css .='}';
	}

	/*------------- Button Settings option-------------------*/
	$advance_training_academy_button_padding_top_bottom = get_theme_mod('advance_training_academy_button_padding_top_bottom');
	$advance_training_academy_button_padding_left_right = get_theme_mod('advance_training_academy_button_padding_left_right');
	$advance_training_academy_custom_css .=' #comments .form-submit input[type="submit"],#category .explore-btn a{';
		$advance_training_academy_custom_css .='padding-top: '.esc_attr($advance_training_academy_button_padding_top_bottom).'px !important; padding-bottom: '.esc_attr($advance_training_academy_button_padding_top_bottom).'px !important; padding-left: '.esc_attr($advance_training_academy_button_padding_left_right).'px !important; padding-right: '.esc_attr($advance_training_academy_button_padding_left_right).'px !important; display:inline-block;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_button_border_radius = get_theme_mod('advance_training_academy_button_border_radius');
	$advance_training_academy_custom_css .=' #comments .form-submit input[type="submit"], #category .explore-btn a{';
		$advance_training_academy_custom_css .='border-radius: '.esc_attr($advance_training_academy_button_border_radius).'px;';
	$advance_training_academy_custom_css .='}';

	/*------------------ Skin Option  -------------------*/
	$advance_training_academy_theme_lay = get_theme_mod( 'advance_training_academy_background_skin_mode','With Background');
    if($advance_training_academy_theme_lay == 'With Background'){
		$advance_training_academy_custom_css .='.page-box, #sidebar .widget,.woocommerce ul.products li.product, .woocommerce-page ul.products li.product,.front-page-content,.background-img-skin, .noresult-content{';
			$advance_training_academy_custom_css .='background-color: #fff;';
		$advance_training_academy_custom_css .='}';
	}else if($advance_training_academy_theme_lay == 'Transparent Background'){
		$advance_training_academy_custom_css .='.page-box-single, .page-box, #sidebar .widget,.woocommerce ul.products li.product, .woocommerce-page ul.products li.product,.front-page-content,.background-img-skin, .noresult-content{';
			$advance_training_academy_custom_css .='background-color: transparent;';
		$advance_training_academy_custom_css .='}';
	}

	/*------------ Woocommerce Settings  --------------*/
	$advance_training_academy_top_bottom_product_button_padding = get_theme_mod('advance_training_academy_top_bottom_product_button_padding', 10);
	$advance_training_academy_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled], .woocommerce a.added_to_cart.wc-forward{';
		$advance_training_academy_custom_css .='padding-top: '.esc_attr($advance_training_academy_top_bottom_product_button_padding).'px; padding-bottom: '.esc_attr($advance_training_academy_top_bottom_product_button_padding).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_left_right_product_button_padding = get_theme_mod('advance_training_academy_left_right_product_button_padding', 16);
	$advance_training_academy_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled], .woocommerce a.added_to_cart.wc-forward{';
		$advance_training_academy_custom_css .='padding-left: '.esc_attr($advance_training_academy_left_right_product_button_padding).'px; padding-right: '.esc_attr($advance_training_academy_left_right_product_button_padding).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_product_button_border_radius = get_theme_mod('advance_training_academy_product_button_border_radius', 0);
	$advance_training_academy_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled], .woocommerce a.added_to_cart.wc-forward{';
		$advance_training_academy_custom_css .='border-radius: '.esc_attr($advance_training_academy_product_button_border_radius).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_show_related_products = get_theme_mod('advance_training_academy_show_related_products',true);
	if($advance_training_academy_show_related_products == false){
		$advance_training_academy_custom_css .='.related.products{';
			$advance_training_academy_custom_css .='display: none;';
		$advance_training_academy_custom_css .='}';
	}

	$advance_training_academy_show_wooproducts_border = get_theme_mod('advance_training_academy_show_wooproducts_border', false);
	if($advance_training_academy_show_wooproducts_border == true){
		$advance_training_academy_custom_css .='.products li{';
			$advance_training_academy_custom_css .='border: 1px solid #767676;';
		$advance_training_academy_custom_css .='}';
	}

	$advance_training_academy_top_bottom_wooproducts_padding = get_theme_mod('advance_training_academy_top_bottom_wooproducts_padding',0);
	$advance_training_academy_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$advance_training_academy_custom_css .='padding-top: '.esc_attr($advance_training_academy_top_bottom_wooproducts_padding).'px !important; padding-bottom: '.esc_attr($advance_training_academy_top_bottom_wooproducts_padding).'px !important;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_left_right_wooproducts_padding = get_theme_mod('advance_training_academy_left_right_wooproducts_padding',0);
	$advance_training_academy_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$advance_training_academy_custom_css .='padding-left: '.esc_attr($advance_training_academy_left_right_wooproducts_padding).'px !important; padding-right: '.esc_attr($advance_training_academy_left_right_wooproducts_padding).'px !important;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_wooproducts_border_radius = get_theme_mod('advance_training_academy_wooproducts_border_radius',0);
	$advance_training_academy_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$advance_training_academy_custom_css .='border-radius: '.esc_attr($advance_training_academy_wooproducts_border_radius).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_wooproducts_box_shadow = get_theme_mod('advance_training_academy_wooproducts_box_shadow',0);
	$advance_training_academy_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$advance_training_academy_custom_css .='box-shadow: '.esc_attr($advance_training_academy_wooproducts_box_shadow).'px '.esc_attr($advance_training_academy_wooproducts_box_shadow).'px '.esc_attr($advance_training_academy_wooproducts_box_shadow).'px #e4e4e4;';
	$advance_training_academy_custom_css .='}';

	/*-------------- Footer Text -------------------*/
	$advance_training_academy_copyright_content_align = get_theme_mod('advance_training_academy_copyright_content_align');
	if($advance_training_academy_copyright_content_align != false){
		$advance_training_academy_custom_css .='.copyright{';
			$advance_training_academy_custom_css .='text-align: '.esc_attr($advance_training_academy_copyright_content_align).';';
		$advance_training_academy_custom_css .='}';
	}

	$advance_training_academy_footer_content_font_size = get_theme_mod('advance_training_academy_footer_content_font_size', 16);
	$advance_training_academy_custom_css .='.copyright p{';
		$advance_training_academy_custom_css .='font-size: '.esc_attr($advance_training_academy_footer_content_font_size).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_copyright_padding = get_theme_mod('advance_training_academy_copyright_padding', 15);
	$advance_training_academy_custom_css .='.copyright{';
		$advance_training_academy_custom_css .='padding-top: '.esc_attr($advance_training_academy_copyright_padding).'px; padding-bottom: '.esc_attr($advance_training_academy_copyright_padding).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_footer_widget_bg_color = get_theme_mod('advance_training_academy_footer_widget_bg_color');
	$advance_training_academy_custom_css .='#footer{';
		$advance_training_academy_custom_css .='background-color: '.esc_attr($advance_training_academy_footer_widget_bg_color).';';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_footer_widget_bg_image = get_theme_mod('advance_training_academy_footer_widget_bg_image');
	if($advance_training_academy_footer_widget_bg_image != false){
		$advance_training_academy_custom_css .='#footer{';
			$advance_training_academy_custom_css .='background: url('.esc_attr($advance_training_academy_footer_widget_bg_image).');';
		$advance_training_academy_custom_css .='}';
	}

	// scroll to top
	$advance_training_academy_scroll_font_size_icon = get_theme_mod('advance_training_academy_scroll_font_size_icon', 22);
	$advance_training_academy_custom_css .='#scroll-top .fas{';
		$advance_training_academy_custom_css .='font-size: '.esc_attr($advance_training_academy_scroll_font_size_icon).'px;';
	$advance_training_academy_custom_css .='}';

	// site title and tagline font size option
	$advance_training_academy_site_title_size_option = get_theme_mod('advance_training_academy_site_title_size_option', 30);{
	$advance_training_academy_custom_css .='.logo h1 a, .logo p a{';
	$advance_training_academy_custom_css .='font-size: '.esc_attr($advance_training_academy_site_title_size_option).'px;';
		$advance_training_academy_custom_css .='}';
	}

	$advance_training_academy_site_tagline_size_option = get_theme_mod('advance_training_academy_site_tagline_size_option', 13);{
	$advance_training_academy_custom_css .='.logo p{';
	$advance_training_academy_custom_css .='font-size: '.esc_attr($advance_training_academy_site_tagline_size_option).'px !important;';
		$advance_training_academy_custom_css .='}';
	}

	// woocommerce product sale settings
	$advance_training_academy_border_radius_product_sale = get_theme_mod('advance_training_academy_border_radius_product_sale',0);
	$advance_training_academy_custom_css .='.woocommerce span.onsale {';
		$advance_training_academy_custom_css .='border-radius: '.esc_attr($advance_training_academy_border_radius_product_sale).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_align_product_sale = get_theme_mod('advance_training_academy_align_product_sale', 'Right');
	if($advance_training_academy_align_product_sale == 'Right' ){
		$advance_training_academy_custom_css .='.woocommerce ul.products li.product .onsale{';
			$advance_training_academy_custom_css .=' left:auto; right:0;';
		$advance_training_academy_custom_css .='}';
	}elseif($advance_training_academy_align_product_sale == 'Left' ){
		$advance_training_academy_custom_css .='.woocommerce ul.products li.product .onsale{';
			$advance_training_academy_custom_css .=' left:0; right:auto;';
		$advance_training_academy_custom_css .='}';
	}

	$advance_training_academy_product_sale_font_size = get_theme_mod('advance_training_academy_product_sale_font_size',14);
	$advance_training_academy_custom_css .='.woocommerce span.onsale{';
		$advance_training_academy_custom_css .='font-size: '.esc_attr($advance_training_academy_product_sale_font_size).'px;';
	$advance_training_academy_custom_css .='}';

	// preloader background option
	$advance_training_academy_loader_background_color_settings = get_theme_mod('advance_training_academy_loader_background_color_settings');
	$advance_training_academy_custom_css .='#loader-wrapper .loader-section{';
		$advance_training_academy_custom_css .='background-color: '.esc_attr($advance_training_academy_loader_background_color_settings).';';
	$advance_training_academy_custom_css .='} ';

	// woocommerce Product Navigation
	$advance_training_academy_products_navigation = get_theme_mod('advance_training_academy_products_navigation', 'Yes');
	if($advance_training_academy_products_navigation == 'No'){
		$advance_training_academy_custom_css .='.woocommerce nav.woocommerce-pagination{';
			$advance_training_academy_custom_css .='display: none;';
		$advance_training_academy_custom_css .='}';
	}

	// featured image setting
	$advance_training_academy_featured_img_border_radius = get_theme_mod('advance_training_academy_featured_img_border_radius', 0);
	$advance_training_academy_custom_css .='.our-services img, .box-img img{';
		$advance_training_academy_custom_css .='border-radius: '.esc_attr($advance_training_academy_featured_img_border_radius).'px;';
	$advance_training_academy_custom_css .='}';

	$advance_training_academy_featured_img_box_shadow = get_theme_mod('advance_training_academy_featured_img_box_shadow',0);
	$advance_training_academy_custom_css .='.our-services img, .page-box-single img{';
		$advance_training_academy_custom_css .='box-shadow: '.esc_attr($advance_training_academy_featured_img_box_shadow).'px '.esc_attr($advance_training_academy_featured_img_box_shadow).'px '.esc_attr($advance_training_academy_featured_img_box_shadow).'px #ccc;';
	$advance_training_academy_custom_css .='}';
